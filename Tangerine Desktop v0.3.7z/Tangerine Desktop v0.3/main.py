isWorking = True
menu = 0
submenu = 0
item = 1
inp = "none"
current = 0

print('Starting up Tangerine Desktop BETA 0.3')
print(' +--+--+')
print(" |     |")
print(' |TDesk|')
print(' +-----+')
print('Loading assets...')
print('Finsesed loading assets.')
print('Loading standart applications')
print('Finished loading applictaions')
current == 0
while isWorking:
    print("+------------------------------+")
    if current == 0:
        if menu == 1:
            print("<Tangerine Desktop> Desktop")
            if item == 1:
                print("<Shut down>")
                print("About")
            elif item == 2:
                print("Shut down")
                print("<About>")        
        elif menu == 2:
                print("Tangerine Desktop <Desktop>")           
        else:
            print("Tangerine Desktop  Desktop")
    elif current == 1:
        if menu == 1:
            print("<Tangerine Desktop> About")
            if item == 1:
                print("<Shut down>")
                print("About")
            elif item == 2:
                print("Shut down")
                print("<About>")        
        elif menu == 2:
                print("Tangerine Desktop <About>")           
        else:
            print("Tangerine Desktop  About")        
    
    if current == 0:
        print("\n\n\n\n\n")
    if current == 1:
        print("+X-----About------------------+")
        print("About Tangerine Desktop")
        print("Tangerine Desktop BETA 0.3")
        print("\n\n")
    print("Input:", end='')
    inp = input()
    if inp == "menu":
        if current == 0:
            print("Possible menus:")
            print("1 : main system menu")
            print("2 : desktop menu")
        elif current == 1:
            print("Possible menus:")
            print("1 : main system menu")
            print("2 : application menu")            
        print("Press Enter to continue", end ="")
        input()        
    elif inp == "menu 1":
        menu = 1
    elif inp == "menu 2":
        menu = 2    
    elif inp == "help":
        print("Avalible commands:\nmenu\nitem\nconfirm\nexit\nclose")
        print("Press Enter to continue", end ="")
        input()
    elif inp == "item":
        if menu == 1:
            print("Possible items:\n1 : Shut down\n2 : About system")
            print("Press Enter to continue", end ="")
            input()            
        if menu == 2:
            print("Not avalible!")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "item 1":
        if menu == 1:
            item = 1
        elif menu == 2:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "item 2":
        if menu == 1:
            item = 2
        elif menu == 2:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "confirm":
        if menu == 1 and item == 1:
            break
        elif menu == 1 and item == 2:
            current = 1
            item == 1
            menu = 0
        else:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "exit":
        menu = 0
        item = 0
    elif inp == "close":
        current = 0
        
        
print('Shutting down...')