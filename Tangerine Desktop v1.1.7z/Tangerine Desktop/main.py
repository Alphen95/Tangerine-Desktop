import random
import time
isWorking = True
inp = "none"
current = 0
op =""
program1 =""
program2 =""
operation = "+"
num1 = 0
num2 = 0
answer = 0
ptsAmount = 501
executingNow = 0
memory = "512KB"
bought = False
counter = 0
grid = {"1":"","2":"","3":"","4":"","5":"","6":"","7":"","8":"","9":"","10":"","11":"","12":"","13":"","14":"","15":"","16":""}
selected = 1
balance = 200
devs = 0
berry = 0
garden = 0
ask = ""
chance = 0
num = 0
machineWorking = True
cycle = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,1,16]

#Hey! You looking at my code!
#Anyways, if you want to modify game, there is progam codes:
#0 : Desktop
#1 : About window
#2 : Calculator
#3 : Launcher
#4 : Hardware Upgrade
#5 : DevCity Builder 95
while machineWorking:
    print('Starting up Tangerine Desktop 1')
    print('Loading system...')
    print('Finsesed loading system.')
    print('Loading standart applications')
    time.sleep(2)
    print('Finished loading applictaions')
    isWorking = True
    time.sleep(3)
    current == 0
    while isWorking:
        chance = random.randint(0,99)
        if chance == 1:
            print("+ -Very important shutdown----+")
            print("|To apply very needen updates,|")
            print("|you have to restart your     |")
            print("|system                       |")
            ask = input("|(Y/N):")
            if ask == "N" or ask == "n":
                print("Good choice!")
                ask = ""
            else:
                time.sleep(1)
                print("I just wanted to prank u!")
                break
                
        if current == 0:
            print("\n\n\n\n\n")
        if current == 1:
            print("+X-----About------------------+")
            print("About Tangerine Desktop")
            print("Tangerine Desktop Dev Preview 1\nProcessor : Lentium I 240 KhZ\nRAM :",memory,"meRAM\nPoints : ", ptsAmount)
            print("\n")
        if current == 2:
            print("+X----Calculator--------------+")
            print("1 Number:" , end="")
            print(num1)
            print("2 Number:" , end="")
            print(num2)
            print("Operation(+/-):", end="")
            print(operation)
            print("Answer:", end = "")
            if operation == "+":
                answer = num1 + num2
            elif operation == "-":
                answer = num1 - num2
            print(answer)
            print("To get help, print: help calc")
        if current == 3:
            print("+--Launcher-------------------+")
            print("Print esc to exit\nShutdown for shutdown/restart\n1 : About\n2 : Calculator\n3 : Hardware Upgrade\n4 : DevCity Builder 95\n")
        if current == 4:
            print("+X-Hardware Update------------+")
            print("Products:\n1MB meRAM")
            if memory != "1MB":
                print("Avalible\nPrint *buy_1* to puchase it")
            else:
                print("Not avalible =(")
            print("\n\n")
        if current == 5:
            print("+X-DevCity Builder 95---------+")
            print("To get help, type 'help DevCity'")
            print("       1 2 3 4")
            print("1 line",grid["1"],grid["2"],grid["3"],grid["4"])
            print("2 line",grid["5"],grid["6"],grid["7"],grid["8"])
            print("3 line",grid["9"],grid["10"],grid["11"],grid["12"])
            print("4 line",grid["13"],grid["14"],grid["15"],grid["16"])
            print("Balance:",balance)
            print("Berries:",berry)
                    
        print("      Launcher 1 Desk 2",program1," ",end = "")
        if program2 != "":
            print("3",program2)
        else:
            print("")    
        print("Input:", end='')
        inp = input()
        if inp == "help":
            print("Avalible commands:\nshutdown\nconfirm\nexit\nclose\nlauncher\nswitch")
            print("Press Enter to continue", end ="")
            input()               
        elif inp == "confirm":
            print("Not used/implemented!")            
        elif inp == "shutdown":
            ask = input("(R)estart,(S)hutdown?:")
            if ask == "R" or ask == "r" or ask == "Restart" or ask == "restart":
                print("Now restarting...")
                for selected in mylist:
                    grid[selected] = ""
            elif ask == "S" or ask == "s" or ask == "Shutdown" or ask == "shutdown":
                print("Now shutting down...")
                time.sleep(2)
                machineWorking = False
                isWorking = False
        elif inp == "close":
            if current == 3:
                if executingNow == 0:
                    current = 0
                elif executingNow == 1:
                    if program1 == "About":
                        currrent = 1
                    elif program1 == "Calc":
                        current = 2
                    elif program1 == "Upgrade":
                        current = 4
                    elif program1 == "DevCity":
                        current = 5
                elif executingNow == 2:
                    if program2 == "About":
                        currrent = 1
                    elif program2 == "Calc":
                        current = 2
                    elif program2 == "Upgrade":
                        current = 4
                    elif program2 == "DevCity":
                        current = 5
            if current == 5:
                for selected in mylist:
                    grid[selected] = ""
                balance = 200
                berry = 0
                devs = 0
                garden = 0
            if current != 0 and current !=2:
                current = 0
                if executingNow == 1:
                    executingNow = 0
                    if program2 != "":
                        program1 = program2
                        program2 = ""
                    else:
                        program1 = ""
                    
            elif current == 2:
                current = 0
                num1 = 0
                num2 = 0
                operation = "+"
                if executingNow == 1:
                    executingNow = 0
                    if program2 != "":
                        program1 = program2
                        program2 = ""
                    else:
                        program1 = ""            
            else:
                print("You want to shut down system?(Y/N):", end ="")
                ask = input()
                if ask == "Y" or ask == "y":
                    isWorking = False
                    machineWorking = False
                else:
                    print("Canceled.")
        elif inp == "launcher":
            current = 3
        elif inp == "1" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "About"
                    current = 1
            else:
                executingNow = 1
                program1 = "About"
                current = 1
        elif inp == "2" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "Calc"
                    current = 2
            else:
                executingNow = 1
                program1 = "Calc"
                current = 2
            
        elif inp == "3" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "Upgrade"
                    current = 4
            else:
                executingNow = 1
                program1 = "Upgrade"
                current = 4
        elif inp == "4" and current == 3:
            current = 5
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")
                else:
                    executingNow = 2
                    program2 = "DevCity"                
            else:
                executingNow = 1
                program1 = "DevCity"    
        elif inp == "help calc":
            print("Help for Calculator")
            print("Commands:")
            print("num1 : set first number")
            print("num2 : set second number")
            print("op : set operation")
        elif inp == "num 1" and current == 2:
            print("Enter first number:", end="")
            num1 = int(input())
        elif inp == "num 2" and current == 2:
            print("Enter second number:", end="")
            num2 = int(input())
        elif inp == "op" and current == 2:
            print("Enter operation(+/-):", end="")
            op = input()
            if op == "+":
                operation = "+"
            elif op == "-":
                operation = "-"
            else:
                print("Wrong operation! Command cancelled.")
        elif inp == "buy_1":
            if bought != False:
                if current == 4:
                    if ptsAmount >= 500:
                        memory = "1MB"
                        bought = False
                        print("Thank you for puchasing our product!")
                    else:
                        print("Error! Not enoungh points!")              
        elif inp == "switch":
            if executingNow == 0:
                executingNow = 1
                if program1 == "About":
                    current = 1
                elif program1 == "Calc":
                    current = 2
                elif program1 == "Upgrade":
                    current = 4
                elif program1 == "DevCity":
                    current = 5                
            elif executingNow == 1:
                executingNow = 2
                if program2 == "About":
                    current = 1
                elif program2 == "Calc":
                    current = 2
                elif program2 == "Upgrade":
                    current = 4
                elif program1 == "DevCity":
                    current = 5            
            elif executingNow == 2:
                executingNow = 0
                current = 0
        elif inp == "next" and current == 5:
            intro = False
        elif inp == "help DevCity" and current == 5:
            print("Help for DevCity Builder 95")
            print("square 1-16 : select square")
            print("build : select building to place")
            print("remove : remove building")
            print("day : end day")
            print("For continuation, press enter or return:",end = "")
            input()
            print("check : check your stats")
            print("transfer : transfers amount of money to points(100 $ = 10 pts")
            print("WARNING!!!! GAME DON'T SAVE YOUR PROGRESS!")
            print("Press enter to continue...",end = "")
            input()
        elif inp == "FULL":
            ptsAmount == 100000000000000
            print("Cheat sucessfuly applied.")
            print("Sorry, Tangerine Desktop 1 has crashed.\n:(\nReason:U_CHEATED_>:(((((")
            print("Press ENTER or Return to shut down", end = "")
            input()
            print("Shutting down...")
            machineWorking = False
            isWorking = False
        elif inp == "square 1" and current == 5:
            selected = 1
        elif inp == "square 2" and current == 5:
            selected = 2
        elif inp == "square 3" and current == 5:
            selected = 3
        elif inp == "square 4" and current == 5:
            selected = 4
        elif inp == "square 5" and current == 5:
            selected = 5
        elif inp == "square 6" and current == 5:
            selected = 6
        elif inp == "square 7" and current == 5:
            selected = 7
        elif inp == "square 8" and current == 5:
            selected = 8
        elif inp == "square 9" and current == 5:
            selected = 9
        elif inp == "square 10" and current == 5:
            selected = 10
        elif inp == "square 11" and current == 5:
            selected = 11
        elif inp == "square 12" and current == 5:
            selected = 12
        elif inp == "square 13" and current == 5:
            selected = 13
        elif inp == "square 14" and current == 5:
            selected = 14
        elif inp == "square 15" and current == 5:
            selected = 15
        elif inp == "square 16" and current == 5:
            selected = 16
        elif inp == "build" and current == 5:
            print("Select what to build:\n(D)ev House : Produces money, but needs 1 berry/day\nPrice : 50 $\n(G)arden : Produces berries but needs 10 $/day\nPrice : 70 $")
            ask = input("D/G:")
            if ask == "D" or ask == "d":
                if selected == 1 and grid["1"] == "":
                    grid["1"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 2 and grid["2"] == "":
                    grid["2"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 3 and grid["3"] == "":
                    grid["3"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 4 and grid["4"] == "":
                    grid["4"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 5 and grid["5"] == "":
                    grid["5"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 6 and grid["6"] == "":
                    grid["6"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 7 and grid["7"] == "":
                    grid["7"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 8 and grid["8"] == "":
                    grid["8"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 9 and grid["9"] == "":
                    grid["9"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 10 and grid["10"] == "":
                    grid["10"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 11 and grid["11"] == "":
                    grid["11"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 12 and grid["12"] == "":
                    grid["12"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 13 and grid["13"] == "":
                    grid["13"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 14 and grid["14"] == "":
                    grid["14"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 15 and grid["15"] == "":
                    grid["15"] = "D"
                    devs=+1
                    balance = balance - 50
                elif selected == 16 and grid["16"] == "":
                    grid["16"] = "D"
                    devs=+1
                    balance = balance - 50
            elif ask == "G" or ask == "g":
                if selected == 1 and grid["1"] == "":
                    grid["1"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 2 and grid["2"] == "":
                    grid["2"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 3 and grid["3"] == "":
                    grid["3"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 4 and grid["4"] == "":
                    grid["4"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 5 and grid["5"] == "":
                    grid["5"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 6 and grid["6"] == "":
                    grid["6"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 7 and grid["7"] == "":
                    grid["7"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 8 and grid["8"] == "":
                    grid["8"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 9 and grid["9"] == "":
                    grid["9"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 10 and grid["10"] == "":
                    grid["10"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 11 and grid["11"] == "":
                    grid["11"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 12 and grid["12"] == "":
                    grid["12"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 13 and grid["13"] == "":
                    grid["13"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 14 and grid["14"] == "":
                    grid["14"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 15 and grid["15"] == "":
                    grid["15"] = "D"
                    garden=+1
                    balance = balance - 70
                elif selected == 16 and grid["16"] == "":
                    grid["16"] = "D"
                    garden=+1
                    balance = balance - 70
            else:
                print("Invalid selection - Operation canceled.")
        elif inp == "remove":
            ask = input("Continue?(Y/N)>")
            if ask == "Y" or ask == "y":
                if grid[selected] != "":
                    grid[selected] = ""
                    print("Operation finished - No refund gotten")
                else:
                    print("Operation was not succesful")
        elif inp == "day" and current == 5:
            balance = balance + devs * 25
            berry = berry + garden * 2
            balance = balance - garden * 10
            berry = berry - devs
        elif inp == "check" and current == 5:
            print("Balance:",balance)
            print("Berries:",berry)
            print("Devs:",devs)
            print("Gardens:",garden)
        elif inp == "transfer":
            print("You can get:",balance/10)
            ask = input("Continue?(Y/N):")
            if ask == "Y" or ask == "y":
                num = int(input("Enter amount of points to get(10 $ = 1 point)"))
                num = num * 10
                if num <= balance:
                    balance = balance - num
                    num = num / 10
                    balance = balance + num
                    print("Transaction succesful. Added",num,"points.")
                    num = 0
                else:
                    print("Transaction was not succesful. Reason: NOT_ENOUGH_MONEY")
        else:
            print("Invalid synatcsis!")        
                
print("Thank you for taking a look at my project!")