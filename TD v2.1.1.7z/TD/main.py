import random
from time import sleep
from colorama import init,Fore,Back
isWorking = True
inp = "none"
current = 0
op =""
program1 =""
program2 =""
operation = "+"
num1 = 0
num2 = 0
answer = 0
ptsAmount = 100
executingNow = 0
memory = "512KB"
bought = False
bought1 = False
counter = 0
grid = {"1":"","2":"","3":"","4":"","5":"","6":"","7":"","8":"","9":"","10":"","11":"","12":"","13":"","14":"","15":"","16":""}
selected = 1
ask = ""
chance = 0
num = 0
processor = 1
machineWorking = True
cycle = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,1,16]
username = ""
name = 0
os = 0
workcycle = True
isAlpha = False
taken = False
name = ""
count = 0
spareint = int
os = ""
osDict = {"1":"TD 2","2":"TD 1","3":"TD 1.1","4":"TD 2","0":"TD 2","6":"PB 3.14","7":"PB 3.14","8":"PB 95","9":"PB RT 3.62","5":"PB 95"}
alreadyChecked = True
#function block start

def cls():
    for i in (0,999999999999999999999999999999999999999999999999999999):
        print("\n\n\n\n\n\n\n\n")
def logon(name):
    print("            Tangerine Desktop   2.1                ")
    print("                              |                    ")
    print("                              |                    ")
    print("                              |                    ")
    print("             welcome          | ",name)
    print("      Hit Enter to log in     |                    ")
    print("                              |                    ")
    print("                              |                    ")
    print("                              |                    ")
    input()
def SysPass(name,os):
    print(" ___________SysPassport___________")
    print("/                                 \\")
    print("|Name:"+name)
    print("|OS:"+os)
    print("|                                 |")
    print("\\_________________________________/")

#Hey! You looking at my code!
#Anyways, if you want to modify game, there is progam codes:
#0 : Desktop
#1 : About window
#2 : Calculator
#3 : Launcher
#4 : Hardware Upgrade
#5 : Settings, Please!
init()
print(Fore.BLACK+Back.WHITE)

with open("name.txt", mode = "r") as NameFile1:
    username = NameFile1.read()
while machineWorking:
    cls()
    print('Starting up TD 2.0')
    print('Loading system...')
    print('Finsesed loading system.')
    print('Loading standart applications')
    sleep(2)
    print('Finished loading applictaions')
    print("          "+Fore.RED+" __+___")
    print("          "+Fore.YELLOW+"/      \\")
    print("          "+Fore.GREEN+"|      |")
    print("          "+Fore.BLUE+"|      |")
    print("          "+Fore.MAGENTA+"\\______/"+Fore.BLACK)
    print("            TD 2.1 ")
    isWorking = True
    sleep(3)
    cls()
    logon(username)
    current == 0
    while isWorking:
        
            
        cls()
        chance = random.randint(0,99)
        if chance == 0:
            print(Back.GREEN+Fore.BLACK+"+ -Very important shutdown----+"+Back.WHITE+Fore.BLACK)
            print("|To apply very needen updates,|")
            print("|you have to restart your     |")
            print("|system                       |")
            ask = input("|(Y/N):")
            if ask == "N" or ask == "n":
                print("Good choice!")
                ask = ""
                cls()
            else:
                print("I just wanted to prank u!")
                sleep(1)
                break
        print(Back.GREEN+Fore.BLACK+"+--------------------------Tangerine Desktop------------------------------+"+Back.WHITE+Fore.BLACK)        
        if current == 0:
            print("\n\n\n\n\n")
        if current == 1:
            print(Back.GREEN+Fore.BLACK+"+X-----About------------------+"+Back.WHITE+Fore.BLACK)
            print("About Tangerine Desktop")
            print("Tangerine Desktop 2.1 Build 13\nProcessor : ",end="")
            if processor == 1:
                print("Lentium 1 115 MhZ\nRAM :",memory,"meRAM\nPoints : ", ptsAmount)
            elif processor == 2:
                print("AMB C6 178 MhZ\nRAM :",memory,"meRAM\nPoints : ", ptsAmount)
            print("\n")
        if current == 2:
            print(Back.GREEN+Fore.BLACK+"+X----Calculator--------------+"+Back.WHITE+Fore.BLACK)
            print("1 Number:" , end="")
            print(num1)
            print("2 Number:" , end="")
            print(num2)
            print("Operation(+/-):", end="")
            print(operation)
            print("Answer:", end = "")
            if operation == "+":
                answer = num1 + num2
            elif operation == "-":
                answer = num1 - num2
            print(answer)
            print("To get help, print: help calc")
        if current == 3:
            print(Back.GREEN+Fore.BLACK+"+--Launcher-------------------+"+Back.WHITE+Fore.BLACK)
            print("Current user:"+username)
            print("Print esc to exit\nShutdown for shutdown/restart\n1 : About\n2 : Calculator\n3 : Hardware Upgrade\n4 : Settings, please!\n5 : Settings")
        if current == 4:
            print(Back.GREEN+Fore.BLACK+"+X-Hardware Update------------+"+Back.WHITE+Fore.BLACK)
            print("Products:\n1MB meRAM")
            if memory != "1MB":
                print("Avalible\nPrint *buy_1* to puchase it\nCost : 500 pts")
            else:
                print("Not avalible =(")
            print("AMB C6 178 MhZ")
            if processor != 1:
                print("Avalible\nPrint *buy_2* to puchase it\nCost : 1000 pts")
            else:
                print("Not avalible =(")
            print("\n\n")
        if current == 5:
            print(Back.GREEN+Fore.BLACK+"+X-Settings, Please!----------------------------------+"+Back.WHITE+Fore.BLACK)
            print("1 right stamp = 10 pts\n1 wrong stamp = -5 pts") 
            if not(alreadyChecked):
                print("")
            else:
                alreadyChecked = False
                name = ""
                while count < 16:
                    spareint = random.randint(1,86)
                    if spareint == 1:
                        name = name + "A"
                    elif spareint == 2:
                        name = name + "B"                
                    elif spareint == 3:
                        name = name + "C"
                    elif spareint == 4:
                        name = name + "D"
                    elif spareint == 5:
                        name = name + "E"                
                    elif spareint == 6:
                        name = name + "F"
                    elif spareint == 7:
                        name = name + "G"
                    elif spareint == 8:
                        name = name + "H"                
                    elif spareint == 9:
                        name = name + "I"
                    elif spareint == 10:
                        name = name + "J"
                    elif spareint == 11:
                        name = name + "K"                
                    elif spareint == 12:
                        name = name + "L"
                    elif spareint == 13:
                        name = name + "M"
                    elif spareint == 14:
                        name = name + "N"                
                    elif spareint == 15:
                        name = name + "O"
                    elif spareint == 16:
                        name = name + "P"
                    elif spareint == 17:
                        name = name + "Q"                
                    elif spareint == 18:
                        name = name + "R"
                    elif spareint == 19:
                        name = name + "S" 
                    elif spareint == 20:
                        name = name + "T"                
                    elif spareint == 21:
                        name = name + "U"
                    elif spareint == 22:
                        name = name + "V"
                    elif spareint == 23:
                        name = name + "W"                
                    elif spareint == 24:
                        name = name + "X"
                    elif spareint == 25:
                        name = name + "Y"
                    elif spareint == 26:
                        name = name + "Z"                
                    elif spareint == 27:
                        name = name + "a"
                    elif spareint == 28:
                        name = name + "b"                
                    elif spareint == 29:
                        name = name + "c"
                    elif spareint == 30:
                        name = name + "d"
                    elif spareint == 31:
                        name = name + "e"                
                    elif spareint == 32:
                        name = name + "f"
                    elif spareint == 33:
                        name = name + "g"
                    elif spareint == 34:
                        name = name + "h"                
                    elif spareint == 35:
                        name = name + "i"
                    elif spareint == 36:
                        name = name + "j"
                    elif spareint == 37:
                        name = name + "k"                
                    elif spareint == 38:
                        name = name + "l"
                    elif spareint == 39:
                        name = name + "m"
                    elif spareint == 40:
                        name = name + "n"                
                    elif spareint == 41:
                        name = name + "o"
                    elif spareint == 42:
                        name = name + "p"
                    elif spareint == 43:
                        name = name + "q"                
                    elif spareint == 44:
                        name = name + "r"
                    elif spareint == 45:
                        name = name + "s" 
                    elif spareint == 46:
                        name = name + "t"                
                    elif spareint == 47:
                        name = name + "u"
                    elif spareint == 48:
                        name = name + "v"
                    elif spareint == 49:
                        name = name + "w"                
                    elif spareint == 50:
                        name = name + "x"
                    elif spareint == 51:
                        name = name + "y"
                    elif spareint == 52:
                        name = name + "z"
                    elif spareint == 53:
                        name = name + "1"
                    elif spareint == 54:
                        name = name + "2"                
                    elif spareint == 55:
                        name = name + "3"
                    elif spareint == 56:
                        name = name + "4"
                    elif spareint == 57:
                        name = name + "5"                
                    elif spareint == 58:
                        name = name + "6"
                    elif spareint == 59:
                        name = name + "7"
                    elif spareint == 60:
                        name = name + "8"                
                    elif spareint == 61:
                        name = name + "9"
                    elif spareint == 62:
                        name = name + "0"
                    elif spareint == 63:
                        name = name + "|"                
                    elif spareint == 64:
                        name = name + "/"
                    elif spareint == 65:
                        name = name + "-"
                    elif spareint == 66:
                        name = name + "_"                
                    elif spareint == 67:
                        name = name + "-"
                    elif spareint == 68:
                        name = name + "!"
                    elif spareint == 69:
                        name = name + "@"                
                    elif spareint == 70:
                        name = name + "#"
                    elif spareint == 71:
                        name = name + "$" 
                    elif spareint == 72:
                        name = name + "%"                
                    elif spareint == 73:
                        name = name + "^"
                    elif spareint == 74:
                        name = name + "&"
                    elif spareint == 75:
                        name = name + "*"                
                    elif spareint == 76:
                        name = name + "("
                    elif spareint == 77:
                        name = name + ")"
                    elif spareint == 78:
                        name = name + "+"
                    elif spareint == 79:
                        name = name + "="                
                    elif spareint == 80:
                        name = name + "["
                    elif spareint == 81:
                        name = name + "]"
                    elif spareint == 82:
                        name = name + "{"
                    elif spareint == 83:
                        name = name + "}"                
                    elif spareint == 84:
                        name = name + "?"
                    elif spareint == 85:
                        name = name + ","
                    elif spareint == 86:
                        name = name + "."
                    count = count + 1
                spareint = random.randint(0,9)
                os = osDict[str(spareint)]
                count = 0 
            
            SysPass(name,os)
            print("(A)ccept,(D)ecline,view (I)nstructions")
            
        if current == 6:
            print(Back.GREEN+Fore.BLACK+"+X-Settings-------------------+"+Back.WHITE+Fore.BLACK)
            print("Username:"+username)
            print("=Change=\n\n\n")
                    
        print("      Launcher 1 Desk 2",program1," ",end = "")
        if program2 != "":
            print("3",program2)
        else:
            print("")    
        inp = input(">")
        if inp == "help":
            print(Back.GREEN+Fore.BLACK+"+Help-----------------------+"+Back.WHITE+Fore.BLACK)
            print("Avalible commands:\nshutdown\nconfirm\nexit\nclose\nlauncher\nswitch")
            print("Press Enter to continue", end ="")
            input()               
        elif inp == "confirm":
            print("Not used/implemented!")  
        elif inp == "change":
            username = input("Enter new username:")
            with open("name.txt", mode = "w+") as NameFile1:
                NameFile1.write(username)
        elif inp == "shutdown":
            ask = input("(R)estart,(S)hutdown?:")
            if ask == "R" or ask == "r" or ask == "Restart" or ask == "restart":
                print("Now restarting...")
                for selected in (1,17):
                    grid[selected] = ""
                isWorking = False
                cls()
            elif ask == "S" or ask == "s" or ask == "Shutdown" or ask == "shutdown":
                print("Now shutting down...")
                sleep(2)
                machineWorking = False
                isWorking = False
        elif inp == "close":
            if current == 3:
                if executingNow == 0:
                    current = 0
                elif executingNow == 1:
                    if program1 == "About":
                        currrent = 1
                    elif program1 == "Calc":
                        current = 2
                    elif program1 == "Upgrade":
                        current = 4
                    elif program1 == "SP":
                        current = 5
                    elif program1 == "Settings":
                        current = 6
                elif executingNow == 2:
                    if program2 == "About":
                        currrent = 1
                    elif program2 == "Calc":
                        current = 2
                    elif program2 == "Upgrade":
                        current = 4
                    elif program2 == "DevCity":
                        current = 5
                    elif program2 == "SP":
                        current = 6
            if current == 5:
                for selected in mylist:
                    grid[selected] = ""
                balance = 200
                berry = 0
                devs = 0
                garden = 0
            if current != 0 and current !=2:
                current = 0
                if executingNow == 1:
                    executingNow = 0
                    if program2 != "":
                        program1 = program2
                        program2 = ""
                    else:
                        program1 = ""
                    
            elif current == 2:
                current = 0
                num1 = 0
                num2 = 0
                operation = "+"
                if executingNow == 1:
                    executingNow = 0
                    if program2 != "":
                        program1 = program2
                        program2 = ""
                    else:
                        program1 = ""            
            else:
                print("You want to shut down system?(Y/N):", end ="")
                ask = input()
                if ask == "Y" or ask == "y":
                    isWorking = False
                    machineWorking = False
                else:
                    print("Canceled.")
        elif inp == "launcher":
            current = 3
        elif inp == "1" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "About"
                    current = 1
            else:
                executingNow = 1
                program1 = "About"
                current = 1
        elif inp == "2" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "Calc"
                    current = 2
            else:
                executingNow = 1
                program1 = "Calc"
                current = 2
            
        elif inp == "3" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "Upgrade"
                    current = 4
            else:
                executingNow = 1
                program1 = "Upgrade"
                current = 4
        elif inp == "4" and current == 3:
            current = 5
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")
                else:
                    executingNow = 2
                    program2 = "DevCity"                
            else:
                executingNow = 1
                program1 = "DevCity"
        elif inp == "5" and current == 3:
            
            if program1 != "":
                if memory != "1MB":
                    print("Low on memory! Operation canceled.")            
                else:
                    executingNow = 2
                    program2 = "Settings"
                    current = 6
            else:
                executingNow = 1
                program1 = "Settings"
                current = 6       
        elif inp == "help calc":
            print("Help for Calculator")
            print("Commands:")
            print("num1 : set first number")
            print("num2 : set second number")
            print("op : set operation")
        elif inp == "num 1" and current == 2:
            print("Enter first number:", end="")
            num1 = int(input())
        elif inp == "num 2" and current == 2:
            print("Enter second number:", end="")
            num2 = int(input())
        elif inp == "op" and current == 2:
            print("Enter operation(+/-):", end="")
            op = input()
            if op == "+":
                operation = "+"
            elif op == "-":
                operation = "-"
            else:
                print("Wrong operation! Command cancelled.")
        elif inp == "buy_1":
            if bought != False:
                if current == 4:
                    if ptsAmount >= 500:
                        memory = "1MB"
                        bought = False
                        print("Thank you for puchasing our product!")
                    else:
                        print("Error! Not enoungh points!") 
        elif inp == "buy_2":
            if bought != False:
                if current == 4:
                    if ptsAmount >= 1000:
                        processor = 2
                        bought1 = False
                        print("Thank you for puchasing our product!")
                    else:
                        print("Error! Not enoungh points!") 
        elif inp == "switch":
            if executingNow == 0:
                executingNow = 1
                if program1 == "About":
                    current = 1
                elif program1 == "Calc":
                    current = 2
                elif program1 == "Upgrade":
                    current = 4
                elif program1 == "SP":
                    current = 5
                elif program1 == "Settings":
                    current = 6
            elif executingNow == 1:
                if program1 != "":
                    executingNow = 2
                    if program2 == "About":
                        current = 1
                    elif program2 == "Calc":
                        current = 2
                    elif program2 == "Upgrade":
                        current = 4
                    elif program1 == "SP":
                        current = 5
                    elif program1 == "Settings":
                        current = 6 
                else:
                    executingNow = 0
                    current = 0
            elif executingNow == 2:
                executingNow = 0
                current = 0
        elif inp == "":
            #Do nothing...
            print("")
        elif inp == "A" and current == 5:
            isAlpha = name.isalpha
            if isAlpha and "TD" in os:
                print("Valid! +10 pts!")
                input("Hit ENTER to continue..")
            else:
                print("Not valid! -5 pts!")
                input("Hit ENTER to continue..")
            alreadyChecked = True
        elif inp == "D" and current == 5:
            isAlpha = name.isalpha
            if isAlpha or not("TD" in os):
                print("Valid! +10 pts!")
                input("Hit ENTER to continue..")
            else:
                print("Not valid! -5 pts!")
                input("Hit ENTER to continue..")
            alreadyChecked = True
        elif inp == "I" and current == 5:
            print("Instructions:\n1:Only letters in name\n2.Let in only TD users")
        else:
            print("Unknown command.")
            input("Hit ENTER to continue...")
                
print("Thank you for taking a look at my project! :D")