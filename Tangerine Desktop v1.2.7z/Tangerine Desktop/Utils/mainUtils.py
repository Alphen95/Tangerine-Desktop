#Main Utils module

def clearscreen():
    '''
    DOCSTRING : Clears screen
    INPUT : none
    OUTPUT : none
    '''
    for i in (0,100000000):
        print("\n\n\n\n\n\n\n")
def greet(username ):
    '''
    DOCSTRING : prints "Greet" screen with selected username
    INPUT : username
    OUTPUT : none
    '''
    clearscreen()
    print("                 |          ")
    print("                 |          ")
    print("    welcome      |",username )
    print("                 |          ")
    print("                 |          ")
    input("Hit Enter to log in:")