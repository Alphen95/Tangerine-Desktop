isWorking = True
menu = 0
submenu = 0
item = 1
inp = "none"

print('Starting up Tangerine Desktop BETA 0.1')
print(' +--+--+')
print(" |     |")
print(' | TDE |')
print(' +-----+')
print('Loading assets...')
print('Finsesed loading assets.')
print('Loading standart applications')
print('Finished loading applictaions')
while isWorking:
    print("+------------------------------+")
    if menu == 1:
        print("<Tangerine Desktop> Edit")
        if item == 1:
            print("<Shut down>")
            print("About")
        elif item == 2:
            print("Shut down")
            print("<About>")        
    elif menu == 2:
            print("Tangerine Desktop <Edit>")           
    else:
        print("Tangerine Desktop  Edit")
    
    print("\n\n\n\n\n")
    print("Input:", end='')
    inp = input()
    if inp == "menu":
        print("Possible menus:")
        print("1 : main system menu")
        print("2 : edit menu")
        print("Press Enter to continue", end ="")
        input()        
    elif inp == "menu 1":
        menu = 1
    elif inp == "menu 2":
        menu = 2    
    elif inp == "help":
        print("Avalible commands:\nmenu\nitem\nconfirm\nexit")
        print("Press Enter to continue", end ="")
        input()
    elif inp == "item":
        if menu == 1:
            print("Possible items:\n1 : Shut down\n2 : About system")
            print("Press Enter to continue", end ="")
            input()            
        if menu == 2:
            print("Not avalible!")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "item 1":
        if menu == 1:
            item = 1
        elif menu == 2:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "item 2":
        if menu == 1:
            item = 2
        elif menu == 2:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "confirm":
        if menu == 1 and item == 1:
            break
        else:
            print("Not avalible")
            print("Press Enter to continue", end ="")
            input()            
    elif inp == "exit":
        menu = 0
        item = 0
        
        
print('Shutting down...')